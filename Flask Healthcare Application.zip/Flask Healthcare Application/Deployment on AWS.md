# Deployment on AWS

Deploy the Flask application on AWS. Here is a detailed guide:

## Launch an EC2 Instance
1. Log in to your AWS Console and navigate to EC2.
2. Launch a new instance with the appropriate configuration.

## Install Required Software
1. SSH into your instance and update the package list:
    ```bash
    sudo apt update
    sudo apt upgrade
    ```

## Install Python, Flask, and MongoDB
1. Install Python and Flask:
    ```bash
    sudo apt install python3-pip
    pip3 install flask pymongo
    ```
2. Install MongoDB:
    ```bash
    sudo apt install mongodb
    ```

## Clone Your Flask Application
1. Clone your repository:
    ```bash
    git clone <repository-url>
    cd <repository-directory>
    ```

## Run the Flask Application
1. Start the Flask application:
    ```bash
    python3 app.py
    ```

## Install and Configure Gunicorn
1. Install Gunicorn:
    ```bash
    pip3 install gunicorn
    ```
2. Run the Flask application with Gunicorn:
    ```bash
    gunicorn --bind 0.0.0.0:8000 app:app
    ```

## Configure Nginx as a Reverse Proxy
1. Install Nginx:
    ```bash
    sudo apt install nginx
    ```
2. Configure Nginx to proxy requests to Gunicorn:
    ```bash
    sudo nano /etc/nginx/sites-available/default
    ```
3. Add the following configuration:
    ```nginx
    server {
        listen 80;
        server_name your_domain_or_IP;

        location / {
            proxy_pass http://127.0.0.1:8000;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
        }
    }
    ```

4. Restart Nginx:
    ```bash
    sudo systemctl restart nginx
    ```
