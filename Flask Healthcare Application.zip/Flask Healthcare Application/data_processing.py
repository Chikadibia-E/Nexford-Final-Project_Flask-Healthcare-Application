import csv
from pymongo import MongoClient

class User:
    def __init__(self, age, gender, total_income, expenses):
        self.age = age
        self.gender = gender
        self.total_income = total_income
        self.expenses = expenses

def fetch_data():
    client = MongoClient('mongodb://localhost:27017/')
    db = client['survey_db']
    collection = db['user_data']
    return collection.find()

def save_to_csv(data):
    with open('user_data.csv', mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['Age', 'Gender', 'Total Income', 'Utilities', 'Entertainment', 'School Fees', 'Shopping', 'Healthcare'])
        for user in data:
            writer.writerow([user['age'], user['gender'], user['total_income'], user['expenses']['utilities'], user['expenses']['entertainment'], user['expenses']['school_fees'], user['expenses']['shopping'], user['expenses']['healthcare']])

if __name__ == '__main__':
    data = fetch_data()
    save_to_csv(data)
